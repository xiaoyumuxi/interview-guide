# Changelog

## 2026-07-28 — Phase 1.5 audit fixes

- Fixed hard-negative CSV identity fields being overwritten by empty metric values.
- Added `NEGATIVE_BEARING` derived evaluation group and effective mapping/pairwise
  denominators.
- Added explicit lexical-approximate and local Hugging Face Qwen token counters;
  existing chunk boundaries remain unchanged.
- Added isolated cold-cache and uniformly preloaded warm-cache ablation performance
  measurements.
- Added complete shared experiment metadata with top-level `test_executed=false`.
- Documented Hard Query Dev as a Dev-evidence-based query stress set rather than
  an independent generalization evaluation.
- Added audit regression tests, fix report, token comparison, performance reports,
  and an updated ablation raw artifact while preserving original quality metrics.
