# Resume Material — Phase 1.5

## 可直接使用

基于 JavaGuide 与 advanced-java 固定版本真实 Markdown 语料搭建 RAG
离线评测流水线，通过可回放 Evidence Span、区间去重、分级
Evidence Recall/Coverage、Context Precision 与 Hard Negative 排序指标，
受控比较 Fixed、Structure-Aware、Parent-Child 三种分块策略。

在 80 条 **Agent-reviewed Dev** 上，Structure-Aware 相比 Fixed 将
EvidenceRecall@5/50 从 0.9361 提升到 0.9658、ContextPrecision@5 从
0.1220 提升到 0.2085；同时构建 48 条 **Agent-reviewed-not-human Hard
Dev**，发现 Fixed 在困难集严格 Recall 更高（0.7812 vs 0.7118），据此否决
“单一策略全面迁移”的过度结论。

针对多知识段问题实现纯 Query 驱动的中文规则拆分、Multi-Query Exact
Retrieval、RRF、Section Diversity 与预算化 Context Assembly；通过
S0–S3 消融发现当前方案在 Multi-Section 上无收益且查询调用增加约 60%，
因此未建议默认上线。

## 简短版本

搭建真实 Java 面试语料 RAG Offline Evaluation Pipeline，以 source-span
Coverage、Context Precision 和 Hard Negative margin 评测检索；实现
Query Decomposition/RRF/Diversity 消融，并用 Agent-reviewed Dev 数据识别
并否决高成本、无收益的 Multi-Query 方案。

## 边界声明

- 数字均为本地 Qwen3-Embedding-0.6B + Exact Cosine 的 Agent-reviewed
  Dev/Hard Dev 实验。
- Test 非人工审核、未冻结，状态为 `NOT EXECUTED`。
- 不使用“最终 Recall”“线上效果”“生产 A/B”“全面提升”等表述。
