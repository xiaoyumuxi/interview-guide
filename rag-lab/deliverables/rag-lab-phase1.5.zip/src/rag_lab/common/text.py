from __future__ import annotations

import hashlib
import re
import unicodedata
from dataclasses import dataclass

TOKEN_RE = re.compile(r"[A-Za-z0-9_./:+#-]+|[\u3400-\u9fff]|[^\s]", re.UNICODE)


@dataclass(frozen=True)
class TokenSpan:
  text: str
  start: int
  end: int


def token_spans(text: str) -> list[TokenSpan]:
  return [TokenSpan(match.group(), match.start(), match.end()) for match in TOKEN_RE.finditer(text)]


def token_count(text: str) -> int:
  return len(token_spans(text))


def normalize_for_hash(text: str) -> str:
  return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", text)).strip()


def text_hash(text: str) -> str:
  return hashlib.sha256(normalize_for_hash(text).encode("utf-8")).hexdigest()


def stable_id(prefix: str, *parts: object) -> str:
  payload = "\x1f".join(str(part) for part in parts)
  return f"{prefix}_{hashlib.sha1(payload.encode('utf-8')).hexdigest()[:16]}"

