#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPERIMENTS = {
  "current_dev": ROOT / "results/raw/20260728T092752Z-49193.json",
  "hard_dev": ROOT / "results/raw/20260728T095847Z-52944.json",
}


def main() -> None:
  fields = [
    "experiment_id", "dataset", "strategy",
    "NegativeExposure@1Query", "NegativeExposure@3Query",
    "NegativeExposure@5Query", "NegativeExposure@10Query",
    "NegativeExposure@1Evidence", "NegativeExposure@3Evidence",
    "NegativeExposure@5Evidence", "NegativeExposure@10Evidence",
    "AverageGoldNegativeScoreMargin", "P50GoldNegativeScoreMargin",
    "MinimumGoldNegativeScoreMargin", "PairwiseGoldWinRate",
    "GoldBeforeNegative@5",
  ]
  rows = []
  for dataset_name, path in EXPERIMENTS.items():
    report = json.loads(path.read_text())
    for strategy, result in report["strategies"].items():
      metrics = result["metrics"].get("HARD_NEGATIVE", {})
      rows.append({
        "experiment_id": report["experiment_id"],
        "dataset": dataset_name,
        "strategy": strategy,
        **{field: metrics.get(field, "") for field in fields},
      })
  output = ROOT / "results/reports/hard-negative-analysis.csv"
  with output.open("w", encoding="utf-8", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)
  print(f"Wrote {len(rows)} rows to {output}")


if __name__ == "__main__":
  main()
