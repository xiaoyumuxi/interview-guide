# rag-lab

`rag-lab` 是 InterviewGuide RAG 模块的独立离线实验环境。它只做文档转换、Evidence
数据集、Chunk 对照、Embedding、精确检索和离线评测，不提供 Web 服务、用户系统、
对话系统或知识库管理。

Phase 1 固定比较三种策略：

- Fixed 512/64
- Markdown Structure-Aware
- Parent-Child

Ground Truth 绑定 normalized Markdown 的 `document_id + [start_offset, end_offset)`，
不绑定任何 Chunk ID，因此同一数据集可以公平评测不同切块边界。

## 数据流

```text
PDF / DOCX / Markdown / HTML / TXT
  -> MarkItDown adapter
  -> normalized Markdown
  -> markdown-it AST + source offsets
  -> evidence-first JSONL
  -> Fixed / Structure-Aware / Parent-Child
  -> local Qwen embedding + SQLite cache
  -> NumPy exact cosine search
  -> HitRate@K / Recall@K / MRR
```

除向量化外，正式数据构建不调用本地或远程生成模型。题目与简洁 Reference Answer
已由子智能体基于固定真实 Evidence 编写并保存为草稿；Qwen 只用于问题语义去重和检索。

## 安装

需要 Python 3.11+ 和 [uv](https://docs.astral.sh/uv/)。

```bash
cd rag-lab
UV_CACHE_DIR=.uv-cache uv sync --extra dev --extra qwen
```

正式实验使用本地 `Qwen/Qwen3-Embedding-0.6B`、1024 维向量和 Apple MPS。
配置保持 `local_files_only: true`；缺少模型会明确失败，不会回退到 mock 或云 API。

## 两套数据

### synthetic-smoke-v1

模板化合成笔记只用于验证 Chunker、Evidence offset、Metric、cache 和 Runner 是否正常。
其结果不得写入简历或作为方案选型证据。

```bash
UV_CACHE_DIR=.uv-cache uv run python scripts/seed_demo_corpus.py
UV_CACHE_DIR=.uv-cache uv run python scripts/benchmark_chunking.py \
  --config configs/baseline.yaml
```

### java-interview-real-v1

正式语料是两个固定 commit 下的 48 篇原始 Markdown，覆盖 Java 基础、集合、JUC、JVM、
Spring、MySQL、Redis、网络、操作系统、分布式、消息队列和系统设计：

- `Snailclimb/JavaGuide`：Apache-2.0
- `doocs/advanced-java`：CC-BY-SA-4.0

仓库 URL、commit、license、相对路径和文件 SHA-256 记录在
[`NOTICE-SOURCES.md`](NOTICE-SOURCES.md)。下载仓库和物化后的完整原文被 `.gitignore`
排除，不提交到 `rag-lab`。

准备固定语料：

```bash
git clone https://github.com/Snailclimb/JavaGuide.git data/sources/JavaGuide
git -C data/sources/JavaGuide checkout 8fb36af2bcd92d87c5223214980a9a97ef946f10
git clone https://github.com/doocs/advanced-java.git data/sources/advanced-java
git -C data/sources/advanced-java checkout 1659850d7de4739ac9394dddd6c68466a8c38761
UV_CACHE_DIR=.uv-cache uv run python scripts/prepare_java_interview_corpus.py
```

候选草稿在 `data/datasets/java-interview-real-v1/agent-drafts/`。构建正式待审数据时，
Qwen embedding 只用于 0.90 阈值的语义去重：

```bash
UV_CACHE_DIR=.uv-cache uv run python scripts/merge_agent_dataset_drafts.py --device mps
UV_CACHE_DIR=.uv-cache uv run python scripts/validate_java_real_dataset.py
```

机器门禁要求：

- 180 条候选，保留 120 条；
- Dev 80 / Test 40，类型配额固定；
- gold 与 hard-negative Evidence 严格等于 normalized Markdown offset 切片；
- Dev/Test 均覆盖 12 类并包含两个来源；
- Evidence ID、Section、文本和实际 offset 区间跨 split 零泄漏；
- `generator_model` 全为空；
- 初始 Test 保持 `PENDING_HUMAN`，不得自动伪装成人工冻结。

## 人工审核与冻结

项目现在额外提供用户要求的子智能体代审版：Dev 80/80、Test 40/40 均通过逐条
release review，输出状态是 `AGENT_APPROVED`。它不是人工审核，Test 仍未冻结。

如仍需满足严格的“真人审核”要求，可运行：

```bash
UV_CACHE_DIR=.uv-cache uv run python scripts/review_and_freeze_test.py \
  --split dev --reviewer YOUR_NAME
UV_CACHE_DIR=.uv-cache uv run python scripts/review_and_freeze_test.py \
  --split test --reviewer YOUR_NAME
```

只有 40 条 Test 全部由真实审核者批准后，脚本才会创建 `test.jsonl` 和
`FROZEN-TEST.json`。正式调参只能使用 Dev；Test 冻结前后均不得用于反复调参。

## 运行 Benchmark

真实 Dev 临时基准：

```bash
UV_CACHE_DIR=.uv-cache uv run python scripts/benchmark_chunking.py \
  --config configs/experiments/qwen-java-interview-real-v1.yaml
```

当前代审版实验 `20260728T083734Z-47450` 使用 48 篇文档和 `AGENT_APPROVED` Dev 80。
Structure-Aware 的
Recall@5 / MRR 为 `0.9749 / 0.9030`，高于 Fixed 的 `0.9635 / 0.8832`；Test 未运行，
所以该结论仍是 Dev 结果，不是冻结 Test 结论。

输出：

- `results/raw/<experiment-id>.json`：配置、环境、数据 SHA、分类型指标和成本；
- `results/reports/java-interview-real-v1-agent-reviewed.csv`：代审 Dev 对照表；
- `data/datasets/java-interview-real-v1/*-agent-reviewed.jsonl`：代审 Dev/Test；
- `results/reports/synthetic-smoke-v1.csv`：仅 Smoke Test；
- `data/cache/*.sqlite3`：以模型、维度、文本类型和 SHA-256 为键的向量缓存。

完整结论与限制见 [`docs/PHASE1-REPORT.md`](docs/PHASE1-REPORT.md)。

## 测试

```bash
UV_CACHE_DIR=.uv-cache uv run pytest
```

Golden tests 覆盖 AST、heading path、list、code fence、table、quote、严格 offset 回放、
三种 Chunker、多 Evidence Recall 和 MRR。Phase 1 不实现 Semantic Chunking、BM25、
Hybrid、Reranker、HNSW 或 LLM-as-a-Judge。
